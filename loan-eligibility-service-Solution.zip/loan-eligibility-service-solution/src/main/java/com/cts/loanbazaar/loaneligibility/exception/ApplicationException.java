/**
 * 
 */
package com.cts.loanbazaar.loaneligibility.exception;

/**
 *
 */
public class ApplicationException extends Exception {

	private static final long serialVersionUID = -9079454849611061074L;
	
	public String errorMessage;

	/**
	 * 
	 */
	public ApplicationException() {
		super();
	}

	/**
	 * @param message
	 */
	public ApplicationException(final String message) {
		super(message);
		this.errorMessage = message;
	}
}
