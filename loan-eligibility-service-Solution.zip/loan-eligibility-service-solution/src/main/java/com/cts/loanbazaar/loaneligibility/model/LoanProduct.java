package com.cts.loanbazaar.loaneligibility.model;

public class LoanProduct {

	public String bankName;
	public String loanProductName;
	public Double maxLoanAmount;
	public Integer tenure;
	public Double interest;
	public Double monthlyInstallment;
	
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	/**
	 * @return the loanProductName
	 */
	public String getLoanProductName() {
		return loanProductName;
	}
	/**
	 * @param loanProductName the loanProductName to set
	 */
	public void setLoanProductName(String loanProductName) {
		this.loanProductName = loanProductName;
	}
	/**
	 * @return the maxLoanAmount
	 */
	public Double getMaxLoanAmount() {
		return maxLoanAmount;
	}
	/**
	 * @param maxLoanAmount the maxLoanAmount to set
	 */
	public void setMaxLoanAmount(Double maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}
	/**
	 * @return the tenure
	 */
	public Integer getTenure() {
		return tenure;
	}
	/**
	 * @param tenure the tenure to set
	 */
	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}
	/**
	 * @return the interest
	 */
	public Double getInterest() {
		return interest;
	}
	/**
	 * @param interest the interest to set
	 */
	public void setInterest(Double interest) {
		this.interest = interest;
	}
	/**
	 * @return the monthlyInstallment
	 */
	public Double getMonthlyInstallment() {
		return monthlyInstallment;
	}
	/**
	 * @param monthlyInstallment the monthlyInstallment to set
	 */
	public void setMonthlyInstallment(Double monthlyInstallment) {
		this.monthlyInstallment = monthlyInstallment;
	}
	
	
}
