/**
 * 
 */
package com.cts.loanbazaar.loaneligibility.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.loanbazaar.loaneligibility.exception.ApplicationException;
import com.cts.loanbazaar.loaneligibility.model.CustomerDetails;
import com.cts.loanbazaar.loaneligibility.service.LoanEligibilityService;

/**
 * Loan Eligibility Controller
 *
 */
@Controller
public class LoanEligibilityController {

	@Autowired
	public LoanEligibilityService service;

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String showHomePage(Model model) {
		model.addAttribute("customerDetails", new CustomerDetails());
		return "loanEligibility";
	}

	@RequestMapping(value = "/eligibilityCheck", method = RequestMethod.POST)
	public String getLoanProducts(Model model, HttpServletRequest request, HttpServletResponse response,
			@Valid @ModelAttribute("customerDetails") CustomerDetails customerDetails, BindingResult result) throws ApplicationException {
		if (result.hasErrors()) {
			return "loanEligibility";
		} else {
			model.addAttribute("loanProducts", service.checkEligibleLoanProducts(customerDetails));
			return "results";
		}
	}

	@ModelAttribute("cities")
	public List<String> getCities() {
		List<String> cities = new ArrayList<String>();
		cities.add("");
		cities.add("Chennai");
		cities.add("Mumbai");
		cities.add("Bangalore");
		cities.add("Delhi");
		cities.add("Kolkatta");
		cities.add("Pune");
		return cities;
	}

	@ModelAttribute("employmentTypes")
	public List<String> getEmploymentTypes() {
		List<String> employementTypes = new ArrayList<String>();
		employementTypes.add("");
		employementTypes.add("Salaried");
		employementTypes.add("Self-Employed");
		employementTypes.add("Contractual Employment");
		employementTypes.add("Student");
		employementTypes.add("Pensioner");
		return employementTypes;
	}

	@ModelAttribute("genderOptions")
	public List<String> getGenderOptions() {
		List<String> genderOptions = new ArrayList<String>();
		genderOptions.add("Male");
		genderOptions.add("Female");
		return genderOptions;
	}

}
