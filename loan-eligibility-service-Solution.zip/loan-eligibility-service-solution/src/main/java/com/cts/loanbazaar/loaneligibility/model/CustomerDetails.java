package com.cts.loanbazaar.loaneligibility.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CustomerDetails {
	
	@Size(min=4, max=30) 
	public String name;
	 
	 @NotNull
	public String gender;
	 
	 @NotEmpty @Email
	public String email;
	 
	 @NotNull
	public Double monthlyIncome;
	  @NotEmpty
	public String customerCity;
	   @NotEmpty
	public String employmentType;
	@NotNull
	public Double desiredLoanAmount;
	
	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}
	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	 
	/**
	 * @return the monthlyIncome
	 */
	public Double getMonthlyIncome() {
		return monthlyIncome;
	}
	/**
	 * @param monthlyIncome the monthlyIncome to set
	 */
	public void setMonthlyIncome(Double monthlyIncome) {
		this.monthlyIncome = monthlyIncome;
	}
	/**
	 * @return the customerCity
	 */
	public String getCustomerCity() {
		return customerCity;
	}
	/**
	 * @param customerCity the customerCity to set
	 */
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	/**
	 * @return the employmentType
	 */
	public String getEmploymentType() {
		return employmentType;
	}
	/**
	 * @param employmentType the employmentType to set
	 */
	public void setEmploymentType(String employmentType) {
		this.employmentType = employmentType;
	}
	/**
	 * @return the desiredLoanAmount
	 */
	public Double getDesiredLoanAmount() {
		return desiredLoanAmount;
	}
	/**
	 * @param desiredLoanAmount the desiredLoanAmount to set
	 */
	public void setDesiredLoanAmount(Double desiredLoanAmount) {
		this.desiredLoanAmount = desiredLoanAmount;
	}
	

}
