package com.cts.loanbazaar.loaneligibility.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.cts.loanbazaar.loaneligibility.model.ErrorResponse;

@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	@ExceptionHandler(ApplicationException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public ModelAndView handleResourceNotFound(final ApplicationException exception,
			final HttpServletRequest request, final Model model) {
		ErrorResponse error = new ErrorResponse(exception.getMessage(), request.getRequestURI());
		model.addAttribute("error", error);
		ModelAndView errorPage = new ModelAndView("error");
		return errorPage;
	}
}
