/**
 * 
 */
package com.cts.loanbazaar.loaneligibility.model;

/**
 *
 */
public class ErrorResponse {
	
	private String errorMessage;
	private String requestedURI;
	
	public ErrorResponse(String errorMessage, String requestedURI) {
		this.errorMessage = errorMessage;
		this.requestedURI = requestedURI;
	}
	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}
	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	/**
	 * @return the requestedURI
	 */
	public String getRequestedURI() {
		return requestedURI;
	}
	/**
	 * @param requestedURI the requestedURI to set
	 */
	public void setRequestedURI(String requestedURI) {
		this.requestedURI = requestedURI;
	}
	
	
}
